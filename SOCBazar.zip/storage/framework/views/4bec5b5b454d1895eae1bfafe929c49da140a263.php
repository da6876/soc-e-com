<!-- ========================= SECTION  ========================= -->
<section class="section-name bg padding-y-sm">
<div class="container">
<header class="section-heading">
	<a href="<?php echo e(url('SeeAllCategorys')); ?>" class="btn btn-outline-primary float-right">See all</a>
	<h3 class="section-title">Popular Categorys</h3>
</header><!-- sect-heading -->

<div class="row">

	<?php
		$categories = DB::select("SELECT A.categories_id, A.categories_name, A.categories_status, A.sub_menu_status,
								(SELECT count(0) FROM products  where category_id=A.categories_id ) AS TotalProduct
								FROM categories A
								WHERE A.categories_status= 'A'
								ORDER BY TotalProduct DESC LIMIT 12");
	?>
	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-2">
	<a href="<?php echo e(URL::to('/show-productsCat').'/'.$categories->categories_name); ?>">
		<figure  class="box item-logo">
			<h5><?php echo e($categories->categories_name); ?></h5>
			<figcaption class="text-center border-top pt-2"><?php echo e($categories->TotalProduct); ?> Products</figcaption>
		</figure> <!-- item-logo.// -->
		</a>
	</div> <!-- col.// -->
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> <!-- row.// -->

</div><!-- container // -->
</section>
<!-- ========================= SECTION  END// ========================= -->
<?php /**PATH E:\xampp\htdocs\SOCBazar\resources\views/layout/category_list.blade.php ENDPATH**/ ?>