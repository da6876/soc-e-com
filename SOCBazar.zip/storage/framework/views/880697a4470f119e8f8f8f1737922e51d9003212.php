<?php $__env->startSection('title', 'Brands'); ?>
<?php echo $__env->make('layout.admin_header_files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
th, td {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 400px;
}
</style>
<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
	<?php echo $__env->make('layout.admin_side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
        <?php echo $__env->make('layout.admin_top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Order </h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="AdminHome">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Order </li>
            </ol>
          </div>

          <div class="row mb-3">
            <!-- Earnings (Monthly) Card Example -->

            <!-- Earnings (Annual) Card Example -->

            <!-- New User Card Example -->

            <!-- Pending Requests Card Example -->
            

            <!-- Area Chart -->
            
            <!-- Pie Chart -->
            
            <!-- Invoice Example -->
            <div class="col-xl-12 col-lg-6 mb-4">
              <div class="card">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Order Info</h6>
                </div>
                <div class="table-responsive p-3">
                  <table class="table align-items-center table-flush" id="dataTable">
                    <thead class="thead-light">
                      <tr>
                        <th>Cust. Contact Info</th>
                        <th>Order Status</th>
                      
                        <th>Order Info</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tfoot>
                      <tr>
                        <th>Cust. Contact Info</th>
                        <th>OrderStatus</th>
                        <th>Order Info</th>
                        <th>Action</th>
                      </tr>
                    </tfoot>
                    <tbody>
                      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <tr>
                        <th>
                            Name : <?php echo e($users->UserInfoName); ?>,<br>
                            Phone : <?php echo e($users->phone); ?>,<br>
                            Email:<?php echo e($users->email); ?>


                        </th>
                          <th>
                              <?php if($users->order_status=='Rejected'): ?>
                                <span class="badge badge-danger"><?php echo e($users->order_status); ?></span>
                              <?php elseif($users->order_status=='Pending'): ?>
                                  <span class="badge badge-secondary"><?php echo e($users->order_status); ?></span>
                              <?php elseif($users->order_status=='Acpect'): ?>
                                  <span class="badge badge-success"><?php echo e($users->order_status); ?></span>
                              <?php elseif($users->order_status=='Processing'): ?>
                                  <span class="badge badge-info"><?php echo e($users->order_status); ?></span>
                              <?php elseif($users->order_status=='Deliver'): ?>
                                  <span class="badge badge-light"><?php echo e($users->order_status); ?></span>
                              <?php elseif($users->order_status=='Confirm'): ?>
                                  <span class="badge badge-primary"><?php echo e($users->order_status); ?></span>
                              <?php else: ?>
                                  <span class="badge badge-gray"><?php echo e($users->order_status); ?></span>
                              <?php endif; ?>
                          </th>
                        <th>
                            Product Name : <?php echo e($users->ProductName); ?>,<br>
                            Order Price : <?php echo e($users->OrderPrice); ?>,<br>
                            Order Quintity :  <?php echo e($users->OrderQuntity); ?>,<br>
                            Shipping Address : <?php echo e($users->ShipingAddress); ?>

                            Order Date : <?php echo e($users->OrderDate); ?>

                        </th>
                        
                        <th>
						<button onclick="AddUserTypeData(<?php echo e($users->order_id); ?>)" class="btn btn-sm btn-primary">Update Status</button>
						</th>
                      </tr>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <div class="card-footer"></div>
              </div>
            </div>
            <!-- Message From Customer-->
            
          </div>
          <!--Row-->



          

        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
		<?php echo $__env->make('layout.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<?php echo $__env->make('layout.admin_footer_files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <!-- Add Modal -->
  <div class="modal fade bd-example-modal-lg" id="modal-add-addBrand" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title"></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <form method="post" id="addData_from"  enctype="multipart/form-data" data-toogle="valibator">
                  <?php echo e(csrf_field()); ?>


                  <div class="modal-body">

                      <div class="row">
                              <input type="hidden" class="form-control" id="OrderId" name="OrderId">
                          <div class="form-group col-md-12">
                              <label for="exampleFormControlSelect1">Status Select</label>
                              <select class="form-control" name="status">
                                  <option value="">Select Status</option>
                                  <option value="Rejected">Rejected</option>
                                  <option value="Accept">Accept</option>
                                  <option value="Processing">Processing</option>
                                  <option value="Deliver">Deliver</option>
                                  <option value="Confirm">Confirm</option>
                              </select>
                          </div>
                      </div>

                      <div class="form-group">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary btn-insert-socialIcon"></button>

                      </div>
                  </div>
              </form>
          </div>
      </div>
  </div>


 <script>


     //Add User Modal Show
     function AddUserTypeData(order_id) {
         save_method = 'updateOder';
         $('input[name_method]').val('POST');
         $('#modal-add-addBrand').modal('show');
         $('.modal-title').text('Add Brand');
         $('.btn-insert-socialIcon').text('Save');
         $('.modal-body').find('textarea,input').val('');
         $("#OrderId").val(order_id)
     }

     //insert Data By Ajax
     $(function () {
         $('#modal-add-addBrand form').on('submit', function (e) {
             if (!e.isDefaultPrevented()) {
                 if (save_method == "updateOder") {
                     url = "<?php echo e(url('ChangeOrder')); ?>";
                     $.ajax({
                         url: url,
                         type: "POST",
                         data: new FormData($("#modal-add-addBrand form")[0]),
                         contentType: false,
                         processData: false,
                         success: function (data) {
                             console.log(data);
                             var dataResult = JSON.parse(data);
                             if (dataResult.statusCode == 200) {
                                 $('#modal-add-adminUser').modal('hide');
                                 swal({
                                     title: "Success",
                                     text: dataResult.statusMsg,
                                     icon: "success",
                                     button: "Great"
                                 }).then((result) => {
                                     window.location.href = 'OrderInfo';
                                 });;
                             } else if (dataResult.statusCode == 201) {
                                 swal({
                                     title: "Oops",
                                     text: "Error occured !",
                                     icon: "error",
                                     timer: '1500'
                                 });
                             }
                         }, error: function (data) {
                             swal({
                                 title: "Oops",
                                 text: "Error occured !",
                                 icon: "error",
                                 timer: '1500'
                             });
                         }
                     });
                     return false;
                 }
             }
         });
     });



</script>
<?php /**PATH E:\xampp\htdocs\SOCBazar\resources\views/adminpart/neworderinfo.blade.php ENDPATH**/ ?>