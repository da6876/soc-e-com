
<nav class="navbar navbar-main navbar-expand-lg navbar-light border-bottom">
  <div class="container">

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main_nav" aria-controls="main_nav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="main_nav">
      <ul class="navbar-nav">
      	<li class="nav-item dropdown">
           <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/')); ?>">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('/')); ?>">Contact us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('MyOrderInfo')); ?>">My Orders</a>
        </li>

      </ul>
    </div> <!-- collapse .// -->
  </div> <!-- container .// -->
</nav>

<?php /**PATH C:\xampp\htdocs\SOCBazar\resources\views/layout/nav_main_menu.blade.php ENDPATH**/ ?>